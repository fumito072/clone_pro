#!/bin/bash
LORA_DIR="$HOME/lora_narisawa"
sed -i.bak "s|/Users/hoshinafumito/development/PresidentClone/mouth_tts/lora_narisawa|${LORA_DIR}|g" ${LORA_DIR}/wav.scp
echo "✅ パス置換完了"
